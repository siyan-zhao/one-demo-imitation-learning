import numpy as np
from gym import utils
from  gym import spaces
import glfw
from gym.gym.spaces.box40 import Box40
from gym.envs.mujoco import mujoco_env
import Box2D
from Box2D.b2 import (edgeShape, circleShape, fixtureDef, polygonShape, revoluteJointDef, contactListener)
import rllab
#from rllab.misc.overrides import overrides

class CylEnv(mujoco_env.MujocoEnv, utils.EzPickle):
    def __init__(self):
        mujoco_env.MujocoEnv.__init__(self, 'cyl.xml', 5)
        utils.EzPickle.__init__(self)

    def step(self, a):
        ctrl_cost_coeff = 0.0001
        xposbefore = self.sim.data.qpos[0]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.sim.data.qpos[0]
        reward_fwd = (xposafter - xposbefore) / self.dt
        reward_ctrl = - ctrl_cost_coeff * np.square(a).sum()
        reward = reward_fwd + reward_ctrl 
        self.viewer = None
        self.action_space = spaces.Box(low=np.array([-40.0,-40.0]),high=np.array([40.0,40.0]),dtype=np.float32)
        #self.world = Box2D.b2World((0,0), contactListener=self.contactListener_keepref)
        self.invisible_state_window = None
        self.invisible_video_window = None
        ob = self._get_obs()
        return ob, reward, False, dict(reward_fwd=reward_fwd, reward_ctrl=reward_ctrl)

    def _get_obs(self):
    
        pos_cyl = self.sim.data.geom_xpos[10][0:2]
        print( "cylinder position", pos_cyl)
        pos_ball = 50 * self.sim.data.geom_xpos[5][0:2]
        #print(pos_ball,"ball position")
        #qpos = self.sim.data.qpos
        #qvel = self.sim.data.qvel
        return np.concatenate([pos_cyl, pos_ball], axis=-1)
        
    def reset_model(self):
        self.set_state(
            self.init_qpos + self.np_random.uniform(low=-.1, high=.1, size=self.model.nq),
            self.init_qvel + self.np_random.uniform(low=-.1, high=.1, size=self.model.nv)
        )
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.trackbodyid = 1
        self.viewer.cam.lookat[0] = 0
        self.viewer.cam.lookat[1] = 0
        self.viewer.cam.lookat[2] = -0.1
        self.viewer.cam.distance = 10
        self.viewer.cam.elevation = -105
        self.viewer.cam.azimuth = 0
    #overrides
    def get_keys_to_action(self):
        lb, ub = [5,-5],[5,-5]
        keys_a={ (ord('t'),):np.array([0, ub[0]*0.3]),
                 (ord('g'),):np.array([0, lb[0]*0.3])}
        return keys_a 
  
    



