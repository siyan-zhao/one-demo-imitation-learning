import gym
import pygame
import numpy as np
import pyglet
from pyglet.window import Window
from pyglet.window import key

window = pyglet.window.Window()
a = np.array([0.0, 0.0])

@window.event
def key_press(k, mod):
        global restart
        print(k)
        if k==0xff0d: restart = True
        if k==key.LEFT:  a[0] = -3.0
        if k==key.RIGHT: a[0] = +3.0
        if k==key.UP:    a[1] = +3.0
        if k==key.DOWN:  a[1] = -3.0
@window.event
def key_release(k, mod):
        if k==key.LEFT  and a[0]==-3.0: a[0] = 0
        if k==key.RIGHT and a[0]==+3.0: a[0] = 0
        if k==key.UP:    a[1] = 0
        if k==key.DOWN:  a[1] = 0
env = gym.make('Cyl-v0')

env.render()
env.viewer.window.on_key_press = key_press
env.viewer.window.on_key_release = key_release
while True:
    env.reset()   
    isopen=True
    while isopen:
      env.reset()
      steps = 0
      while True:
           s, r, done, info = env.step(a)
           if steps % 200 == 0 or done:
                print("\naction " + str(["{:+0.2f}".format(x) for x in a]))
              #  print("step {} total_reward {:+0.2f}".format(steps, total_reward))
                #import matplotlib.pyplot as plt
                #plt.imshow(s)
                #plt.savefig("test.jpeg")
           steps += 1
           isopen = env.render()
           if done or isopen == False:
                break
env.close()

