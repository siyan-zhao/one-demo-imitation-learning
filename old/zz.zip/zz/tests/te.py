import sys, math
import numpy as np

import Box2D
from Box2D.b2 import (edgeShape, circleShape, fixtureDef, polygonShape, revoluteJointDef, contactListener)

import gym
from gym import spaces
from gym.envs.box2d.car_dynamics import Car
from gym.utils import colorize, seeding, EzPickle

import pyglet
from pyglet import gl



if __name__=="__main__":
    from pyglet.window import key
    a = np.array( [0.0, 0.0])
    def key_press(k, mod):
        global a
        if k==0xff0d: restart = True
        if k==key.D:  a[0] = -5.0
        if k==key.A: a[0] = +5.0
        if k==key.W:    a[1] = +5.0
        if k==key.S:  a[1] = -5.0   # set 1.0 for wheels to block to zero rotation
    def key_release(k, mod):
        global a
        if k==key.A:  a[0] = 0
        if k==key.D: a[0] = 0
        if k==key.W:    a[1] = 0
        if k==key.S:  a[1] = 0
    env = gym.make('Cyl-v0')
    print(env.action_space)
    env.render()
    env.unwrapped.viewer.window.on_key_press = key_press
    env.unwrapped.viewer.window.on_key_release = key_release
    record_video = False
    if record_video:
        from gym.wrappers.monitor import Monitor
        env = Monitor(env, '/tmp/video-test', force=True)
    isopen = True
    while isopen:
        env.reset()
        total_reward = 0.0
        steps = 0
        restart = False
        while True:
            s, r, done, info = env.step(a)
            total_reward += r
            if steps % 200 == 0 or done:
                print("\naction " + str(["{:+0.2f}".format(x) for x in a]))
                print("step {} total_reward {:+0.2f}".format(steps, total_reward))  
            steps += 1
            isopen = env.render()
            if done or restart or isopen == False:
                break
    env.close()
