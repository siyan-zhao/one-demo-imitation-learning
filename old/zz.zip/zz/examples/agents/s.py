import gym
from gym.utils import play

env = gym.make('Cyl-v0')
env.reset()

play.play(gym.make('CartPole-v0'), zoom=3)
env.env.close()
#env.render(mode="human")
for i in range(300):
  env.render(mode="human")
